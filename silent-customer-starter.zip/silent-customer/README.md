# Silent Customer — free starter app

A standalone, mobile-friendly QR feedback website using the existing Supabase project. This is separate from Campaign Feedback Rewards and uses only the `sc_businesses` and `sc_feedback` tables.

## Included
- `index.html` — customer landing page, feedback form, email/password auth, business dashboard, QR generation, status workflow, and simple metrics.
- No build step or Lovable credits required.

## Deploy free using GitHub Pages
1. Create a new **public** GitHub repository named `silent-customer` (do not add secrets).
2. Upload `index.html` and this README to the repository root.
3. In the repository, open **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, and save.
5. Wait for GitHub Pages to provide the public website URL.
6. In Supabase Dashboard → Authentication → URL Configuration, add the published website URL to **Redirect URLs**. Keep existing URLs unchanged. Set the Site URL only if you understand it affects other apps using this same Auth project; because Auth is shared, do not change the Site URL just for this app unless you have checked the other apps first.

## Supabase setup already done
The existing project is `qqbziipglucvsdnnpnck`. The app uses its browser-safe publishable key and these new tables:
- `public.sc_businesses`
- `public.sc_feedback`

The database migration was applied and verified. RLS is enabled for both tables. Existing `campaigns`, `campaign_feedback`, and Auth settings were not changed.

## Important
- The publishable key in `index.html` is designed to be public. Never put a `service_role` or secret key in browser code.
- Do not promise customers that submissions are legally anonymous if they voluntarily provide contact details or if your deployment/network logs can identify them.
- This starter uses the same Supabase Auth service, so existing accounts may sign in; creating a separate account is optional. A separate app does not mean separate Auth users.
- Customer feedback can include sensitive complaints. Restrict dashboard access, do not share owner logins, and avoid collecting payment details or sensitive personal information.
- Supabase and GitHub may change free-tier limits or terms. No paid services are required for this static version, but free-tier availability is not guaranteed forever.
- QR generation uses the public `qrcode` CDN library; the Supabase JavaScript SDK is loaded from jsDelivr.
